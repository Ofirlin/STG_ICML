import unittest
import stg 

class TestDataset(unittest.TestCase):
    def hoge(self):
        pass


if __name__ == '__main__':
    unittest.main()